Development moved to https://gitlab.com/blacknet-ninja

https://helleniccoin.org/ aims to continue on HellenicCoin chain.
